		<div class="bg_box "></div>
            <div class="circle_text_box">
                <?php if(!empty($category)): ?>
                <?php  $t=0; ?>
                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php  $t++; $tes=''; if($t>=21 && $t<=40){ $tes='rotate_text';} ?>
                <div class="text text-<?php echo e($t); ?>">
                    <a href="#" class="link_text" data-toggle="tooltip" title="<?php echo e($rows['category_name']); ?>">
                        <span class="text <?php echo e($tes); ?>"><?php echo e($rows['category_name']); ?></span>
                    </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

            </div>
            <?php 
			$i=0;
			$count=count($array)-3;
			foreach($array as $key=>$rows){
			$i++;
			?>
            <div class="ring ring-<?php echo e($i); ?>">
                <?php $j=0; ?>
                <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $j++; 

					$alre=\App\CategoryDetails::where('p_id',$row->id)->first();
					if(!empty($alre)){
						$submit="submit";
						$name=$alre->name;
					

					}else{
						$submit="";
						$name="";
						
					}
					  if($i >$count){ $ani="reverse"; }else{ $ani="forward"; }
				?>
                <div class="dot dot-<?php echo e($j); ?>">
                    <a href="javascript:void(0);" class="fill   <?php echo e($submit); ?> " data-id="<?php echo e($row->id); ?>" id="<?php echo e($row->id); ?>">
                        <!-- <div class="info_box"
                            style="background-image: url(https://s3-eu-west-1.amazonaws.com/devenv-okela-stage/artists/images/000/000/156/medium_dark/avatar.jpg?1585044291);"> -->

                        <div class="info_box"
                            style="background-image: url(https://i.ibb.co/KW2YFRh/Microsoft-Teams-image-44.jpg);">


                            <h6 class="name_text">
                                <span class="first_name"><?php echo e($name); ?></span>
                               
                            </h6>
                        </div>
                    </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php } ?><?php /**PATH E:\xampp\htdocs\do\resources\views/index_load.blade.php ENDPATH**/ ?>